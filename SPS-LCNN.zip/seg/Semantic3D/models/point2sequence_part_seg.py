import os
import sys
BASE_DIR = os.path.dirname(__file__)
sys.path.append(BASE_DIR)
sys.path.append(os.path.join(BASE_DIR, '../utils'))
import tensorflow as tf
import numpy as np
import tf_util
from pointnet_util import *

def placeholder_inputs(batch_size, num_point):
    pointclouds_pl = tf.placeholder(tf.float32, shape=(batch_size, num_point, 6))
    labels_pl = tf.placeholder(tf.int32, shape=(batch_size, num_point))
    return pointclouds_pl, labels_pl


def get_model(point_cloud, is_training, bn_decay=None, part_num=13):
    """ Part segmentation PointNet, input is BxNx6 (XYZ NormalX NormalY NormalZ), output Bx50 """
    batch_size = point_cloud.get_shape()[0].value
    num_point = point_cloud.get_shape()[1].value
    end_points = {}
    l0_xyz = tf.slice(point_cloud, [0,0,0], [-1,-1,3])
    l0_points = tf.slice(point_cloud, [0,0,3], [-1,-1,3])

    # Set Abstraction layers
    # l1_xyz, l1_points = point2sequence_module(l0_xyz, l0_points, 384, [8, 16, 32, 64],[[32, 64, 128], [32, 64, 128], [64, 64, 128], [64, 64, 128]], 128, 128,
    #                                         is_training, bn_decay, batch_size=batch_size, scope='layer1')
    # l2_xyz, l2_points, l2_indices = pointnet_sa_module(l1_xyz, l1_points, npoint=None, radius=None, nsample=None, mlp=[256,512,1024], mlp2=None, group_all=True, is_training=is_training, bn_decay=bn_decay, scope='layer3')

    l0_xyz, l0_points = point2sequence_module(l0_xyz, None, None, None, [16], [64], 0, is_training, bn_decay, scope='layer0', select=False)
    l1_xyz, l1_points = point2sequence_module(l0_xyz, l0_points, 1024, None, [8,16,32,64], [128,128], 128, is_training, bn_decay, scope='layer1')
    l2_xyz, l2_points = point2sequence_module(l1_xyz, l1_points, 512, None, [8,16], [256,256], 256, is_training, bn_decay, scope='layer2')
    l3_xyz, l3_points = conv(l2_points, kernel=[1,1], mlp = [512], stride=[1,1], is_training=is_training, scope='layer4', bn_decay=bn_decay,max_pooling=True)

    # Feature Propagation layers
    l2_points = pointnet_fp_module(l2_xyz, l3_xyz, l2_points, l3_points, [512], is_training, bn_decay, scope='fa_layer0')

    l1_points = pointnet_fp_module(l1_xyz, l2_xyz, l1_points, l2_points, [256], is_training, bn_decay, scope='fa_layer1')

    l0_points = pointnet_fp_module(l0_xyz, l1_xyz, l0_xyz, l1_points, [128,128],
                                   is_training, bn_decay, scope='fa_layer2')

    net_0 = tf.tile(tf.expand_dims(l0_points,axis=-2), [1, 1, 1, 1])
    net_1 = tf.tile(tf.expand_dims(l1_points,axis=-2), [1, num_point//l1_points.get_shape()[1].value, 1, 1])
    net_2 = tf.tile(tf.expand_dims(l2_points,axis=-2), [1, num_point//l2_points.get_shape()[1].value, 1, 1])
    net_3 = tf.tile(tf.expand_dims(l3_points,axis=-2), [1, num_point, 1, 1])

    concat = tf.concat(axis=3, values=[net_0,
                                       net_3])

    # FC layers
    net = tf_util.conv1d(tf.squeeze(concat,axis=2), 128, 1, padding='VALID', bn=True, is_training=is_training, scope='fc1', bn_decay=bn_decay)
    net = tf_util.dropout(net, keep_prob=0.5, is_training=is_training, scope='dp1')
    # net = tf_util.conv1d(tf.squeeze(concat,axis=2), 64, 1, padding='VALID', bn=True, is_training=is_training, scope='fc2', bn_decay=bn_decay)
    end_points['feats'] = net 
    # net = tf_util.dropout(net, keep_prob=0.2, is_training=is_training, scope='dp2')
    net = tf_util.conv1d(net, part_num, 1, padding='VALID', activation_fn=None, scope='fc3')

    return net, end_points


def get_loss(pred, label):
    """ pred: BxNxC,
        label: BxN, """
    loss = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=pred, labels=label)
    classify_loss = tf.reduce_mean(loss)
    tf.summary.scalar('classify loss', classify_loss)
    tf.add_to_collection('losses', classify_loss)
    return classify_loss

if __name__=='__main__':
    with tf.Graph().as_default():
        inputs = tf.zeros((32,2048,6))
        net, _ = get_model(inputs, tf.constant(True))
        print(net)
