""" Point2Sequence Layers

Author: Xinhai Liu
Date: June 2018
"""

import os
import sys
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BASE_DIR)
sys.path.append(os.path.join(ROOT_DIR, 'utils'))
# sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/sampling'))
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/grouping'))
sys.path.append(os.path.join(ROOT_DIR, 'tf_ops/3d_interpolation'))
# from tf_sampling import farthest_point_sample, gather_point
from tf_grouping import query_ball_point
from tf_interpolate import three_nn, three_interpolate
from sklearn.decomposition import PCA
import tensorflow as tf
import math
import numpy as np
import tf_util
import tensorflow.contrib.slim as slim
from layers import *
import pointfly as pf
from tflearn.layers.conv import global_avg_pool,global_max_pool
    
def conv(input_channel, kernel, mlp, stride, is_training, scope, bn_decay, concat=False, concatdata=None,max_pooling=False):
    with tf.variable_scope(scope) as sc:
        if len(input_channel.get_shape().as_list()) !=4:
            input_channel = tf.expand_dims(input_channel,axis=-2)
        # input_channel = tf_util.conv2d(input_channel, mlp2, [1,1],padding='VALID', stride=[1,1], bn=True, is_training=is_training,scope='conv1', bn_decay=bn_decay)
        for i, out_channel in enumerate(mlp):
            if concat:
                if i == len(mlp)-1:
                    input_channel = tf.concat([input_channel,concatdata], axis = -1)
            net = tf_util.conv2d(input_channel, out_channel, kernel,padding='VALID', stride=stride, bn=True, is_training=is_training,scope='conv%d'%(i), bn_decay=bn_decay)
            # net = tf.nn.atrous_conv2d(input_channel, kernel, rate=16, padding="VALID")
            input_channel = net
        if max_pooling:
            net = tf.squeeze(tf.reduce_max(net, axis=[1], keep_dims=True),axis=2)
        # gamma = tf.get_variable("gamma", [1], initializer=tf.constant_initializer(0.0))
        # net = gamma*net+net
        new_xyz = tf.constant(np.tile(np.array([0,0,0]).reshape((1,1,3)), (net.get_shape()[0].value,1,1)),dtype=tf.float32)
    return new_xyz,net

def ECA_model(x, xyz, out_dim, layer_name, is_training, bn_decay):
    with tf.name_scope(layer_name) :
        if len(x.get_shape().as_list()) !=4:
            x = tf.expand_dims(x,axis=-2)
        b, n, kp, c = x.get_shape().as_list()
        input_x = tf.transpose(x, [0,3,2,1])

        # squeeze = Global_Average_Pooling(input_x)

        # squeeze_max = tf.reduce_max(input_x, axis=[1], keep_dims=True, name='maxpool')
        # squeeze_mean = tf.reduce_mean(input_x, axis=[1], keep_dims=True, name='avgpool')
        y_max = global_max_pool(input_x, name='Global_max_pooling')
        # y_mean = global_avg_pool(input_x, name='Global_avg_pooling')
        # y = tf.expand_dims((y_mean + y_max),axis=-1)
        y = tf.expand_dims(y_max,axis=-1)
        # t = int(abs((math.log(n,2)+1)/2))
        # k = t if t%2==0 else t+1
        # if n == 1024:
        #     k = 256
        # elif n == 512:
        #     k = 128
        k = n//4
        y = tf.concat([y,y[:,0:k-1,:]],axis=1)
        # SAME VALID
        y = tf_util.ECA(y, 1, k, padding='VALID', stride=1, scope='layer_name', bn=False, is_training=is_training, bn_decay=bn_decay)

        y = tf.transpose(y, [0,2,1])

        y = tf.nn.sigmoid(y)

        # scale = input_x * excitation
        # scale = tf.transpose(scale, [0,3,2,1])
        # scale = tf.reduce_sum(scale,axis=-1,keep_dims=True)
        # scale = tf.reshape(scale,[scale.get_shape()[0].value,-1,scale.get_shape()[1].value])

        _, nn_idx = tf.nn.top_k(y, k=out_dim, sorted=True)
        # nn_idx = tf.reshape(nn_idx,[nn_idx.get_shape()[0].value,-1,1])
        nn_idx = tf.transpose(nn_idx, [0,2,1])

        x = tf.squeeze(x)
        feature = find_xyz(x, nn_idx)
        new_xyz = tf.squeeze(find_xyz(xyz, nn_idx))
        return new_xyz,feature

def point2sequence_module(xyz, points, npoint1, npoint2, nsample_list, mlp_list, output_size, is_training, bn_decay, scope, radi=None, bn=True, use_xyz=True, use_nchw=False, batch_size=16, select=True, num_groups=2, depth_multiplier=4, attention=False):
    ''' Point2sequence module
        assume mlp[k][-1] are all the same for rnn input
        Input:
            xyz: (batch_size, ndataset, 3) TF tensor
            points: (batch_size, ndataset, channel) TF tensor
            npoint: int32 -- #points sampled in farthest point sampling
            nsample: list of int32 -- how many points in each local region
            mlp: list of list of int32 -- output size for MLP on each point
            hidden_size: int32 -- hidden size of the RNN hidden state
            use_xyz: bool, if True concat XYZ with local point features, otherwise just use point features
            use_nchw: bool, if True, use NCHW data format for conv2d, which is usually faster than NHWC format
        Return:
            new_xyz: (batch_size, npoint, 3) TF tensor
            feature: (batch_size, npoint, output_size}) TF tensor
    '''
    with tf.variable_scope(scope) as sc:
        new_points_list = []

        if select:
            # attention
            # new_xyz,new_feature = attention_select_point(points, points.get_shape()[-1].value, xyz, 'asp', is_training, bn_decay, pointtop=npoint1, pointbom=npoint2)

            # ECA
            new_xyz,new_feature = ECA_model(points, xyz, npoint1, 'sqp', is_training, bn_decay)
            points = tf.squeeze(points)

            # fps
            # idx_fps = farthest_point_sample(npoint1, xyz)
            # new_feature = find_xyz(points, tf.expand_dims(idx_fps,axis=-1))
            # new_xyz = gather_point(xyz, idx_fps)
        else:
            feature = xyz
            new_xyz = xyz

        if nsample_list[0] != 0:
            if radi:
                idx_ = pf.radince_indices_general(new_xyz, xyz, radi[0], nsample_list[-1])
            else:
                idx_ = pf.knn_indices_general(new_xyz, xyz, nsample_list[-1], True)

            grouped_xyz = tf.gather_nd(xyz, idx_)
            if points is not None:
                grouped_points = tf.gather_nd(points, idx_)
                sk_grouped_points,_ = tf.nn.moments(grouped_points, axes=2,keep_dims=True)
                sk_grouped_points = tf.tile(sk_grouped_points, [1, 1, nsample_list[-1], 1])
                grouped_points = tf.concat([sk_grouped_points, grouped_points-sk_grouped_points], axis=-1)

        # local point
        nsample = nsample_list[-1]
        if nsample != 0:
            # grouped_xyz = grouped_xyz_[:,:,int(i*nsample_list[0]):int(i*nsample_list[0])+int(nsample_list[0]),:]
            grouped_xyz1 = grouped_xyz
            grouped_xyz -= tf.tile(tf.expand_dims(new_xyz, 2), [1, 1, nsample, 1])
            if points is not None:
                # grouped_points = grouped_points_[:,:,int(i*nsample_list[0]):int(i*nsample_list[0])+int(nsample_list[0]),:]
                if use_xyz:
                    grouped_points = tf.concat([grouped_xyz1, grouped_xyz, grouped_points], axis=-1)
            else:
                grouped_points = tf.concat([grouped_xyz,tf.tile(tf.expand_dims(xyz, 2), [1, 1, nsample, 1])],axis=-1)
        else:
            if points is not None:
                grouped_points = tf.expand_dims(points,axis=-2)
            else:
                grouped_points = tf.expand_dims(xyz,axis=-2)
        c = 0
        # MLP layers
        for i in range(len(nsample_list)):
            fp = grouped_points[:, :, 0:nsample_list[i], :]
            for j,num_out_channel in enumerate(mlp_list):
                x = fp
                sz = x.get_shape()[3].value // num_groups
                conv_side_layers = []
                for g in range(num_groups):
                    conv_side = tf_util.conv2d(x[:, :, :, g * sz:g * sz + sz], num_out_channel//num_groups, [1,1],
                                                    padding='VALID', stride=[1,1], bn=bn, is_training=is_training,
                                                    scope='conv%d_%d_%d'%(i,j,g), bn_decay=bn_decay)
                    conv_side_layers.append(conv_side)
                feature = tf.concat(conv_side_layers, axis=-1)
                feature = channel_shuffle('channel_shuffle', feature, num_groups)
        	# max pool
            new_points = tf.reduce_max(feature, axis=[2],keep_dims=True)
            new_points_list.append(new_points)

        # multi-scale area feature
        feature = tf.concat(new_points_list, axis=-2)

        if output_size > 0:
            xfeature = feature
            sz = xfeature.get_shape()[3].value // num_groups
            xfeature_layers = []
            for s in range(num_groups):
                conv_side = tf_util.conv2d(xfeature[:, :, :, s * sz:s * sz + sz], num_out_channel//num_groups, [1,feature.get_shape()[2].value],
                                                padding='VALID', stride=[1,1], bn=bn, is_training=is_training,
                                                scope='conv%d'%(s), bn_decay=bn_decay)
                xfeature_layers.append(conv_side)
            feature = tf.concat(xfeature_layers, axis=-1)
            feature = channel_shuffle('channel_shuffle', feature, num_groups)

            # feature = tf_util.conv2d(feature, output_size, [1,feature.get_shape()[2].value],
            #                          padding='VALID', stride=[1,feature.get_shape()[2].value], bn=bn, is_training=is_training,
            #                          scope='conv', bn_decay=bn_decay)
            # new_feature = tf.concat(new_feature_list, axis=-2)
            # print(new_feature)
            # exit()
            # new_feature = tf_util.conv2d(new_feature, output_size, [1,feature.get_shape()[2].value],
            #                                 padding='VALID', stride=[1,1], bn=bn, is_training=is_training,
            #                                 scope='conv_f', bn_decay=bn_decay)
            # feature = tf.squeeze(tf.concat([new_feature,feature], axis=-1),axis=2)
        return new_xyz, tf.squeeze(feature,axis=2)

def pointnet_fp_module(xyz1, xyz2, points1, points2, mlp, is_training, bn_decay, scope, bn=True):
    ''' PointNet Feature Propogation (FP) Module
        Input:
            xyz1: (batch_size, ndataset1, 3) TF tensor
            xyz2: (batch_size, ndataset2, 3) TF tensor, sparser than xyz1
            points1: (batch_size, ndataset1, nchannel1) TF tensor
            points2: (batch_size, ndataset2, nchannel2) TF tensor
            mlp: list of int32 -- output size for MLP on each point
        Return:
            new_points: (batch_size, ndataset1, mlp[-1]) TF tensor
    '''
    with tf.variable_scope(scope) as sc:
        dist, idx = three_nn(xyz1, xyz2)
        dist = tf.maximum(dist, 1e-10)
        norm = tf.reduce_sum((1.0 / dist), axis=2, keep_dims=True)
        norm = tf.tile(norm, [1, 1, 3])
        weight = (1.0/dist) / norm
        interpolated_points = three_interpolate(points2, idx, weight)

        if points1 is not None:
            new_points1 = tf.concat(axis=2, values=[interpolated_points, points1]) # B,ndataset1,nchannel1+nchannel2
        else:
            new_points1 = interpolated_points
        new_points1 = tf.expand_dims(new_points1, 2)
        for i, num_out_channel in enumerate(mlp):
            new_points1 = tf_util.conv2d(new_points1, num_out_channel, [1,1],
                                         padding='VALID', stride=[1,1],
                                         bn=bn, is_training=is_training,
                                         scope='conv_%d'%(i), bn_decay=bn_decay)
        new_points1 = tf.squeeze(new_points1, [2]) # B,ndataset1,mlp[-1]
        return new_points1

def find_xyz(point_cloud, point_idx):
    point_cloud_shape = point_cloud.get_shape()
    batch_size = point_cloud_shape[0].value
    num_points = point_cloud_shape[1].value
    num_dims = point_cloud_shape[2].value
    idx_ = tf.range(batch_size) * num_points
    idx_ = tf.reshape(idx_, [batch_size, 1, 1]) 
    point_cloud_flat = tf.reshape(point_cloud, [-1, num_dims])
    point = tf.gather(point_cloud_flat, point_idx+idx_)
    return point


def distance_matrix(A, B):
    r_A = tf.reduce_sum(A * A, axis=2, keep_dims=True)
    r_B = tf.reduce_sum(B * B, axis=2, keep_dims=True)
    m = tf.matmul(A, tf.transpose(B, perm=(0, 2, 1)))
    D = r_A - 2 * m + tf.transpose(r_B, perm=(0, 2, 1))
    D = tf.sqrt(D)
    return D